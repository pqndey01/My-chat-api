# My-chat-api
A simple real-time chat website built using HTML, CSS, JavaScript and Firebase Realtime Database.
